package com.project.projectKelompok8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectKelompok8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
