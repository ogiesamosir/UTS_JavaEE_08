package com.project.projectKelompok8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectKelompok8Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectKelompok8Application.class, args);
	}

}
